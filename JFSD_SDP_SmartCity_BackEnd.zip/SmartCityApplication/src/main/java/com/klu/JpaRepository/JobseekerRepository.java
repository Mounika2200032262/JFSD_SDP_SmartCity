package com.klu.JpaRepository;
import com.klu.application.entity.Jobseeker;
import org.springframework.data.jpa.repository.JpaRepository;
public interface JobseekerRepository extends JpaRepository<Jobseeker, Long> {

}
