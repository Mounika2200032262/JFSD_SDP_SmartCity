package com.klu.JpaRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.klu.application.entity.Business;

public interface BusinessRepository extends JpaRepository<Business, Long>{

}
