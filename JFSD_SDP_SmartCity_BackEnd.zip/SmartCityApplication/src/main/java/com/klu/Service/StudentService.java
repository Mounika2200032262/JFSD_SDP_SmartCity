package com.klu.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klu.JpaRepository.StudentRepository;
import com.klu.application.entity.Student;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public Student saveStudent(Student student) {
        // Make sure the student object is valid and not null
        if (student != null) {
            return studentRepository.save(student); // Save the student entity to the database
        } else {
            throw new IllegalArgumentException("Student object cannot be null");
        }
    }
}
