package com.klu.Service;

import com.klu.application.entity.Jobseeker;
import com.klu.JpaRepository.JobseekerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JobseekerService {
	 @Autowired
	    private JobseekerRepository jobseekerRepository;

	    public Jobseeker saveJobseeker(Jobseeker jobseeker) {
	        return jobseekerRepository.save(jobseeker);
	    }

}
