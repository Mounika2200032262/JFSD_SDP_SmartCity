package com.klu.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.klu.Service.BusinessService;
import com.klu.application.entity.Business;

@Controller
@RequestMapping("/business")
public class BusinessController {
	   @Autowired
	    private BusinessService businessService;

	    @GetMapping("/register")
	    public String showBusinessRegistrationForm(Model model) {
	        model.addAttribute("business", new Business());
	        return "business_register";
	    }

	    @PostMapping("/register")
	    public String registerBusiness(@ModelAttribute Business business) {
	        businessService.saveBusiness(business);
	        return "redirect:/blogin";
	    }

}
