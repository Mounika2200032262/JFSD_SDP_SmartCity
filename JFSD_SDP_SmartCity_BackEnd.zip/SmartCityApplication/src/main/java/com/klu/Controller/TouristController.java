package com.klu.Controller;

import com.klu.application.entity.Tourist;
import com.klu.Service.TouristService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller  // Use @Controller for returning views
@RequestMapping("/tourist/register")
public class TouristController {

    @Autowired
    private TouristService touristService;

    @GetMapping("/register")  // To display the registration form (GET request)
    public String showTouristRegisterForm() {
        return "tregister";  // This will resolve to /WEB-INF/jsp/tregister.jsp
    }

    @PostMapping("/register")  // To handle the form submission (POST request)
    public String registerTourist(@ModelAttribute Tourist tourist) {
        touristService.saveTourist(tourist);
        return "redirect:/tourist/success";  // Redirect to a success page after registration
    }
}
