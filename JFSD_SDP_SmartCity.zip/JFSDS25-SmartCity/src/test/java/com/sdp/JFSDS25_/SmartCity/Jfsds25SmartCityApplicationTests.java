package com.sdp.JFSDS25_.SmartCity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jfsds25SmartCityApplicationTests {

	@Test
	void contextLoads() {
	}

}
